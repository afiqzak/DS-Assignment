insert into admin
values ('1', 'abu', '10213231', 'uxwiuxbiwbu@gmail.com', '1234', '2004-11-08', 'dsvsvsvss', 'abu', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4');

insert into account
values 	('1234 1233 1234', 'ali bin abu', 'ali', '1012321', 'adhwiu@gmail.com', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '2004-12-02', 'jhjerbcknwkc', 'Platinum Patronus', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '45741.2', '402.24', '152.235'),
	('9224 9335 2558', 'amar bin udin', 'amarudin', '213121', 'hfhfhrth@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2024-05-27', 'dsdcsd, Forbidden Forest', 'Silver Snitch', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '1234', '0', '0'),
        ('7342 2313 1232', 'amad bin rosli', 'amad', '1233892', 'hdhbw9ubcd@gmail.com', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '2004-12-02', 'coecoiebd', 'Golden Galleon', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '324', '445', '875')
	('1245 1233 1312', 'abu bin amad', 'abu', '1023917', 'ucbwiubc@gmail.com', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '2004-12-02', 'kjjdbbciw', 'Silver Snitch', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '722', '322', '5678')
	('9398 9676 5018', 'ali amad', 'amii', '10291301', 'kbbwcjbsov@gmail.com', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '2004-11-02', 'sfbvodfnvois', 'Silver Snitch', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '1234', '4712', '786');

insert into transaction 
values 	('1001', '1234 1233 1234', '7342 2313 1232', '10 G', '1000 G', 'Credit Card', 'Entertainment', '2024-06-15 12:16:56', 'iedciuwb')
	('1002', '1245 1233 1312', '7342 2313 1232', '102 S', '90000 S', 'Debit Card', 'Food', '2024-05-27 12:16:56', 'chrbhieubc')
	('1003', '7342 2313 1232', '1245 1233 1312', '101 G', '3000 G', 'transfer', 'Others', '2024-06-27 12:16:56', 'dceiw')
	('1004', '1234 1233 1234', '1245 1233 1312', '100 K', '1234 K', 'Credit Card', 'Entertainment', '2024-05-03 20:43:14', 'vfsvsdvfsvf')
	('1005', '1234 1233 1234', '7342 2313 1232', '100 K', '1234 K', 'Debit Card', 'Entertainment', '2024-06-03 20:43:14', 'bgfdbdbdf')
	('1006', '1234 1233 1234', '7342 2313 1232', '1000 K', '100 K', 'Credit Card', 'Grocery', '2024-06-12 00:40:30', 'evbbvjs')
	('1007', '1234 1233 1234', '1245 1233 1312', '10 G', '10000 G', 'Debit Card', 'Bill', '2024-06-12 00:40:30', 'vsdbndfndn')
	('1008', '1234 1233 1234', '1245 1233 1312', '22.0 K', '9978.0 K', 'Transfer', 'Others', '2024-06-07 01:55:20', 'Instant transfer to abu bin amad')
	('1009', '1234 1233 1234', '1234 1233 1234', '0.2 K', '392.0 S', 'transfer', 'Exchange', '2024-06-08 22:59:51', 'Convert 10K to 2S')
	('1010', '1234 1233 1234', '1234 1233 1234', '0.2 K', '402.0 S', 'Transfer', 'Exchange', '2024-06-09 20:20:16', 'Convert 123.0 K to 4.24 S');

insert into card
values	('111', '1234 1233 1234', '1012 1910 3932', '11/5', 'debit card', '10000G')
	('123', '1234 1233 1234', '1111 8888 1111', '11/2', 'credit card', '10000S');

insert into currency
values	('1', 'K', 'Knut')
	('2', 'S', 'Sickle')
	('3', 'G', 'Galleon');

insert into exchange_rate
values	('2', '1', '29.000000', '0.2000')
	('3', '1', '493.000000', '0.3000')
	('3', '2', '17.000000', '0.3000');






        
